#pragma once
#include "unicode/uscript.h"


namespace RLL
{
	typedef UScriptCode ScriptCode;
}