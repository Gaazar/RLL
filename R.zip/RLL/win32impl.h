#pragma once
#include "windows.h"
#include "Interfaces.h"
#include "PathGeometry.h"
#define INIT_DIRECTX_DEBUG_LAYER (0x1)
#define INIT_DEVELOP (0x2)

void _DBG_D3DLIVE_OBJ();