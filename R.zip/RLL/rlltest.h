#pragma once
#include "TextInterfaces.h"
RLL::ISVG* hb_test(RLL::IFontFace* ff, RLL::ISVGBuilder* sb, wchar_t* tex);
